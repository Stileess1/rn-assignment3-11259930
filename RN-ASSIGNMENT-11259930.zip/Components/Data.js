export const data = [
    {

    name:"Exercise",
    task:"12 Tasks",
    image:require('../assets/pic1.png'),
    id:'1'
    
    },
    {
        name:"Study",
        task:"12 Tasks",
        image:require('../assets/pic2.png'),
        id:2
    },
]

export const tasks = [
    {
        name:"Mobile App Development",
        id:"1"
    },
    {
        name:"Web Dev",
        id:"2"
    },
    {
        name:"Push Ups",
        id:"3"
    },
    {
        name:"Exercise",
        id:"4"
    },
    {
        name:"Relax",
        id:"5"
    },
    {
        name:"Run",
        id:"6"
    },
    {
        name:"Machine Learning",
        id:"7"
    },
    {
        name:"Ethical Hacking",
        id:"8"
    },
    {
        name:"Read",
        id:"9"
    },
    {
        name:"Walk",
        id:"10"
    },
    {
        name:"Swim",
        id:"11"
    },
    {
        name:"Surf",
        id:"12"
    },
    {
        name:"Drive",
        id:"13"
    },
    {
        name:"Hike",
        id:"14"
    },
    {
        name:"Debug",
        id:"15"
    }
]